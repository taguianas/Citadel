#ifndef __CONFIG_H__
#define __CONFIG_H__

#include "globals.h"
#include "io_utils.h"

int parseConfig(const char *psFilePath, MaesterConfig *pstConfig);
void freeConfig(MaesterConfig *pstConfig);

#endif
