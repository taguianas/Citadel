#ifndef __MAIN_H__
#define __MAIN_H__

#include "globals.h"
#include "io_utils.h"
#include "config.h"
#include "inventory.h"
#include "commands.h"

#define NUM_REQUIRED_ARGS 3

#endif
