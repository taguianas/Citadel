#ifndef __INVENTORY_H__
#define __INVENTORY_H__

#include "globals.h"
#include "io_utils.h"

int loadInventory(const char *psFilePath, Inventory *pstInventory);
void displayInventory(const Inventory *pstInventory);
void freeInventory(Inventory *pstInventory);

#endif
