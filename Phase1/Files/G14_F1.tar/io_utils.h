#ifndef __IO_UTILS_H__
#define __IO_UTILS_H__

#include "globals.h"

void printMessage(const char *psMessage);
void printInt(int nValue);
void printFloat(float fValue);
char *readLine(int nFd);
int stringToInt(const char *psStr);
int compareIgnoreCase(const char *psA, const char *psB);
char *trimWhitespace(char *psStr);
int countWords(const char *psStr);
char *getWord(const char *psStr, int nIndex, char *psBuffer, int nBufferSize);
void stripAmpersand(char *psStr);

#endif
