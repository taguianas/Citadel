#include "io_utils.h"

void printMessage(const char *psMessage) {
    int nLen = 0;
    if (NULL == psMessage) {
        return;
    }
    nLen = strlen(psMessage);
    write(STDOUT_FILENO, psMessage, nLen);
}

void printInt(int nValue) {
    char sBuffer[32];
    int nIndex = 0;
    int nIsNegative = 0;
    int nStart = 0;
    int nEnd = 0;
    char cSwap = 0;

    if (0 == nValue) {
        write(STDOUT_FILENO, "0", 1);
        return;
    }
    if (nValue < 0) {
        nIsNegative = 1;
        nValue = -nValue;
    }
    while (nValue > 0) {
        sBuffer[nIndex] = '0' + (nValue % 10);
        nIndex++;
        nValue = nValue / 10;
    }
    if (nIsNegative) {
        sBuffer[nIndex] = '-';
        nIndex++;
    }
    nStart = 0;
    nEnd = nIndex - 1;
    while (nStart < nEnd) {
        cSwap = sBuffer[nStart];
        sBuffer[nStart] = sBuffer[nEnd];
        sBuffer[nEnd] = cSwap;
        nStart++;
        nEnd--;
    }
    sBuffer[nIndex] = '\0';
    write(STDOUT_FILENO, sBuffer, nIndex);
}

void printFloat(float fValue) {
    int nIntPart = 0;
    int nDecPart = 0;
    float fTemp = 0.0f;

    if (fValue < 0) {
        write(STDOUT_FILENO, "-", 1);
        fValue = -fValue;
    }
    nIntPart = (int)fValue;
    fTemp = (fValue - nIntPart) * 10.0f + 0.5f;
    nDecPart = (int)fTemp;
    if (nDecPart >= 10) {
        nIntPart++;
        nDecPart = 0;
    }
    printInt(nIntPart);
    write(STDOUT_FILENO, ".", 1);
    printInt(nDecPart);
}

char *readLine(int nFd) {
    char cChar = 0;
    int nBytesRead = 0;
    int nCapacity = 128;
    int nLength = 0;
    char *psLine = NULL;
    char *psTemp = NULL;

    psLine = (char *)malloc(nCapacity);
    if (NULL == psLine) {
        return NULL;
    }
    while (1) {
        nBytesRead = read(nFd, &cChar, 1);
        if (nBytesRead <= 0) {
            if (0 == nLength) {
                free(psLine);
                return NULL;
            }
            break;
        }
        if ('\n' == cChar) {
            break;
        }
        if (nLength >= nCapacity - 1) {
            nCapacity = nCapacity * 2;
            psTemp = (char *)realloc(psLine, nCapacity);
            if (NULL == psTemp) {
                free(psLine);
                return NULL;
            }
            psLine = psTemp;
        }
        psLine[nLength] = cChar;
        nLength++;
    }
    psLine[nLength] = '\0';
    return psLine;
}

int stringToInt(const char *psStr) {
    int nResult = 0;
    int nSign = 1;
    int i = 0;

    if (NULL == psStr) {
        return 0;
    }
    while (' ' == psStr[i] || '\t' == psStr[i]) {
        i++;
    }
    if ('-' == psStr[i]) {
        nSign = -1;
        i++;
    } else if ('+' == psStr[i]) {
        i++;
    }
    while (psStr[i] >= '0' && psStr[i] <= '9') {
        nResult = nResult * 10 + (psStr[i] - '0');
        i++;
    }
    return nResult * nSign;
}

int compareIgnoreCase(const char *psA, const char *psB) {
    int i = 0;
    if (NULL == psA || NULL == psB) {
        return -1;
    }
    while (psA[i] != '\0' && psB[i] != '\0') {
        if (tolower((unsigned char)psA[i]) != tolower((unsigned char)psB[i])) {
            return tolower((unsigned char)psA[i]) - tolower((unsigned char)psB[i]);
        }
        i++;
    }
    return tolower((unsigned char)psA[i]) - tolower((unsigned char)psB[i]);
}

char *trimWhitespace(char *psStr) {
    char *psEnd = NULL;
    if (NULL == psStr) {
        return NULL;
    }
    while (' ' == *psStr || '\t' == *psStr || '\r' == *psStr) {
        psStr++;
    }
    if ('\0' == *psStr) {
        return psStr;
    }
    psEnd = psStr + strlen(psStr) - 1;
    while (psEnd > psStr && (' ' == *psEnd || '\t' == *psEnd || '\r' == *psEnd)) {
        psEnd--;
    }
    *(psEnd + 1) = '\0';
    return psStr;
}

int countWords(const char *psStr) {
    int nCount = 0;
    int nInWord = 0;
    int i = 0;

    if (NULL == psStr) {
        return 0;
    }
    for (i = 0; psStr[i] != '\0'; i++) {
        if (' ' == psStr[i] || '\t' == psStr[i]) {
            nInWord = 0;
        } else {
            if (0 == nInWord) {
                nCount++;
                nInWord = 1;
            }
        }
    }
    return nCount;
}

char *getWord(const char *psStr, int nIndex, char *psBuffer, int nBufferSize) {
    int nCurrentWord = 0;
    int nInWord = 0;
    int nWordStart = 0;
    int nWordLen = 0;
    int i = 0;

    if (NULL == psStr || NULL == psBuffer || nBufferSize <= 0) {
        return NULL;
    }
    for (i = 0; psStr[i] != '\0'; i++) {
        if (' ' == psStr[i] || '\t' == psStr[i]) {
            if (nInWord) {
                if (nCurrentWord == nIndex) {
                    nWordLen = i - nWordStart;
                    if (nWordLen >= nBufferSize) {
                        nWordLen = nBufferSize - 1;
                    }
                    memcpy(psBuffer, psStr + nWordStart, nWordLen);
                    psBuffer[nWordLen] = '\0';
                    return psBuffer;
                }
                nCurrentWord++;
                nInWord = 0;
            }
        } else {
            if (0 == nInWord) {
                nWordStart = i;
                nInWord = 1;
            }
        }
    }
    if (nInWord && nCurrentWord == nIndex) {
        nWordLen = i - nWordStart;
        if (nWordLen >= nBufferSize) {
            nWordLen = nBufferSize - 1;
        }
        memcpy(psBuffer, psStr + nWordStart, nWordLen);
        psBuffer[nWordLen] = '\0';
        return psBuffer;
    }
    return NULL;
}

void stripAmpersand(char *psStr) {
    int nRead = 0;
    int nWrite = 0;
    if (NULL == psStr) {
        return;
    }
    for (nRead = 0; psStr[nRead] != '\0'; nRead++) {
        if ('&' != psStr[nRead]) {
            psStr[nWrite] = psStr[nRead];
            nWrite++;
        }
    }
    psStr[nWrite] = '\0';
}
