#ifndef __COMMANDS_H__
#define __COMMANDS_H__

#include "globals.h"
#include "io_utils.h"
#include "config.h"
#include "inventory.h"

int processCommand(const char *psInput, MaesterConfig *pstConfig,
                   Inventory *pstInventory, int *pnRunning);

#endif
