#include "main.h"

static MaesterConfig gstConfig;
static Inventory gstInventory;
static int gnRunning = 1;

static void handleSignal(int nSignal) {
    if (SIGINT == nSignal) {
        printMessage("\n");
        printMessage("The Maester of ");
        printMessage(gstConfig.sRealmName);
        printMessage(" signs off. The ravens rest.\n");
        freeInventory(&gstInventory);
        freeConfig(&gstConfig);
        gnRunning = 0;
        _exit(0);
    }
}

int main(int argc, char *argv[]) {
    char *psLine = NULL;
    struct sigaction stAction;

    if (NUM_REQUIRED_ARGS != argc) {
        printMessage("Usage: Maester <config.dat> <stock.db>\n");
        return 1;
    }

    memset(&stAction, 0, sizeof(stAction));
    stAction.sa_handler = handleSignal;
    sigemptyset(&stAction.sa_mask);
    stAction.sa_flags = 0;
    sigaction(SIGINT, &stAction, NULL);

    memset(&gstConfig, 0, sizeof(MaesterConfig));
    memset(&gstInventory, 0, sizeof(Inventory));

    if (0 != parseConfig(argv[1], &gstConfig)) {
        printMessage("ERROR: Failed to parse configuration file.\n");
        return 1;
    }

    if (0 != loadInventory(argv[2], &gstInventory)) {
        printMessage("ERROR: Failed to load inventory file.\n");
        freeConfig(&gstConfig);
        return 1;
    }

    printMessage("Maester of ");
    printMessage(gstConfig.sRealmName);
    printMessage(" initialized. The board is set.\n");

    gnRunning = 1;
    while (gnRunning) {
        printMessage(PROMPT);
        psLine = readLine(STDIN_FILENO);

        if (NULL == psLine) {
            break;
        }

        processCommand(psLine, &gstConfig, &gstInventory, &gnRunning);
        free(psLine);
    }

    freeInventory(&gstInventory);
    freeConfig(&gstConfig);
    return 0;
}
