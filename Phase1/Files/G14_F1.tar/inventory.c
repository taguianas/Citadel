#include "inventory.h"

int loadInventory(const char *psFilePath, Inventory *pstInventory) {
    int nFd = 0;
    int nBytesRead = 0;
    int nCapacity = 16;
    int nCount = 0;
    Product stTemp;
    Product *pNewArray = NULL;

    if (NULL == psFilePath || NULL == pstInventory) {
        return -1;
    }

    pstInventory->pProducts = NULL;
    pstInventory->nNumProducts = 0;

    nFd = open(psFilePath, O_RDONLY);
    if (nFd < 0) {
        printMessage("ERROR: Could not open inventory file.\n");
        return -1;
    }

    pstInventory->pProducts = (Product *)malloc(sizeof(Product) * nCapacity);
    if (NULL == pstInventory->pProducts) {
        close(nFd);
        return -1;
    }

    nCount = 0;
    while (1) {
        memset(&stTemp, 0, sizeof(Product));

        nBytesRead = read(nFd, stTemp.sName, MAX_PRODUCT_NAME);
        if (nBytesRead <= 0) {
            break;
        }
        if (nBytesRead < MAX_PRODUCT_NAME) {
            break;
        }

        nBytesRead = read(nFd, &stTemp.nAmount, sizeof(int));
        if (nBytesRead < (int)sizeof(int)) {
            break;
        }

        nBytesRead = read(nFd, &stTemp.fWeight, sizeof(float));
        if (nBytesRead < (int)sizeof(float)) {
            break;
        }

        if (nCount >= nCapacity) {
            nCapacity = nCapacity * 2;
            pNewArray = (Product *)realloc(pstInventory->pProducts, sizeof(Product) * nCapacity);
            if (NULL == pNewArray) {
                close(nFd);
                return -1;
            }
            pstInventory->pProducts = pNewArray;
        }

        memcpy(&pstInventory->pProducts[nCount], &stTemp, sizeof(Product));
        nCount++;
    }

    pstInventory->nNumProducts = nCount;
    close(nFd);
    return 0;
}

void displayInventory(const Inventory *pstInventory) {
    int i = 0;
    int j = 0;
    int nNameLen = 0;
    int nPadding = 0;
    int nAmountLen = 0;
    int nValPad = 0;
    int nTempVal = 0;

    if (NULL == pstInventory || NULL == pstInventory->pProducts) {
        printMessage("No inventory loaded.\n");
        return;
    }

    printMessage("--- Trade Ledger ---\n");
    printMessage("Item                 | Value (Gold) | Weight (Stone)\n");
    printMessage("------------------------------------------------------\n");

    for (i = 0; i < pstInventory->nNumProducts; i++) {
        printMessage(pstInventory->pProducts[i].sName);

        nNameLen = strlen(pstInventory->pProducts[i].sName);
        nPadding = 21 - nNameLen;
        if (nPadding < 1) {
            nPadding = 1;
        }
        for (j = 0; j < nPadding; j++) {
            printMessage(" ");
        }

        printMessage("| ");
        printInt(pstInventory->pProducts[i].nAmount);

        nAmountLen = 0;
        nTempVal = pstInventory->pProducts[i].nAmount;
        if (0 == nTempVal) {
            nAmountLen = 1;
        } else {
            while (nTempVal > 0) {
                nAmountLen++;
                nTempVal = nTempVal / 10;
            }
        }
        nValPad = 13 - nAmountLen;
        for (j = 0; j < nValPad; j++) {
            printMessage(" ");
        }

        printMessage("| ");
        printFloat(pstInventory->pProducts[i].fWeight);
        printMessage("\n");
    }

    printMessage("------------------------------------------------------\n");
    printMessage("Total Entries: ");
    printInt(pstInventory->nNumProducts);
    printMessage("\n");
}

void freeInventory(Inventory *pstInventory) {
    if (NULL == pstInventory) {
        return;
    }
    if (NULL != pstInventory->pProducts) {
        free(pstInventory->pProducts);
        pstInventory->pProducts = NULL;
    }
    pstInventory->nNumProducts = 0;
}
