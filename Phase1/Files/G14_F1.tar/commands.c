#include "commands.h"

static void cmdListRealms(MaesterConfig *pstConfig);
static void cmdListProducts(Inventory *pstInventory);
static void cmdStartTrade(const char *psInput, MaesterConfig *pstConfig);
static void cmdExit(MaesterConfig *pstConfig, int *pnRunning);
static void runTradeMenu(const char *psTargetRealm, MaesterConfig *pstConfig);
static int writeTradeFile(const TradeList *pstTradeList, const char *psFolderPath);

int processCommand(const char *psInput, MaesterConfig *pstConfig,
                   Inventory *pstInventory, int *pnRunning) {
    char sWord1[MAX_BUFFER];
    char sWord2[MAX_BUFFER];
    char sWord3[MAX_BUFFER];
    char sWord4[MAX_BUFFER];
    int nWordCount = 0;
    char *psCopy = NULL;
    char *psTrimmed = NULL;

    if (NULL == psInput || NULL == pstConfig || NULL == pstInventory || NULL == pnRunning) {
        return -1;
    }

    psCopy = (char *)malloc(strlen(psInput) + 1);
    if (NULL == psCopy) {
        return -1;
    }
    strcpy(psCopy, psInput);
    psTrimmed = trimWhitespace(psCopy);

    if ('\0' == *psTrimmed) {
        free(psCopy);
        return 0;
    }

    nWordCount = countWords(psTrimmed);
    memset(sWord1, 0, sizeof(sWord1));
    memset(sWord2, 0, sizeof(sWord2));
    memset(sWord3, 0, sizeof(sWord3));
    memset(sWord4, 0, sizeof(sWord4));

    if (nWordCount >= 1) getWord(psTrimmed, 0, sWord1, sizeof(sWord1));
    if (nWordCount >= 2) getWord(psTrimmed, 1, sWord2, sizeof(sWord2));
    if (nWordCount >= 3) getWord(psTrimmed, 2, sWord3, sizeof(sWord3));
    if (nWordCount >= 4) getWord(psTrimmed, 3, sWord4, sizeof(sWord4));

    if (0 == compareIgnoreCase(sWord1, "EXIT") && 1 == nWordCount) {
        cmdExit(pstConfig, pnRunning);
        free(psCopy);
        return 0;
    }

    if (0 == compareIgnoreCase(sWord1, "LIST") && 0 == compareIgnoreCase(sWord2, "REALMS")) {
        if (2 == nWordCount) {
            cmdListRealms(pstConfig);
        } else {
            printMessage("Unknown command\n");
        }
        free(psCopy);
        return 0;
    }

    if (0 == compareIgnoreCase(sWord1, "LIST") && 0 == compareIgnoreCase(sWord2, "PRODUCTS")) {
        if (2 == nWordCount) {
            cmdListProducts(pstInventory);
        } else if (3 == nWordCount) {
            printMessage("Command OK\n");
        } else {
            printMessage("Unknown command\n");
        }
        free(psCopy);
        return 0;
    }

    if (0 == compareIgnoreCase(sWord1, "PLEDGE") && 0 == compareIgnoreCase(sWord2, "RESPOND")) {
        if (4 == nWordCount &&
            (0 == compareIgnoreCase(sWord4, "ACCEPT") || 0 == compareIgnoreCase(sWord4, "REJECT"))) {
            printMessage("Command OK\n");
        } else if (nWordCount < 4) {
            printMessage("Missing arguments for PLEDGE RESPOND. Please review syntax.\n");
        } else {
            printMessage("Unknown command\n");
        }
        free(psCopy);
        return 0;
    }

    if (0 == compareIgnoreCase(sWord1, "PLEDGE") && 0 == compareIgnoreCase(sWord2, "STATUS")) {
        if (2 == nWordCount) {
            printMessage("Command OK\n");
        } else {
            printMessage("Unknown command\n");
        }
        free(psCopy);
        return 0;
    }

    if (0 == compareIgnoreCase(sWord1, "PLEDGE")) {
        if (3 == nWordCount) {
            printMessage("Command OK\n");
        } else if (1 == nWordCount) {
            printMessage("Missing arguments, can't send a pledge. Please review the syntax.\n");
        } else if (2 == nWordCount) {
            printMessage("Missing arguments, can't send a pledge. Please review the syntax.\n");
        } else {
            printMessage("Unknown command\n");
        }
        free(psCopy);
        return 0;
    }

    if (0 == compareIgnoreCase(sWord1, "START") && 0 == compareIgnoreCase(sWord2, "TRADE")) {
        if (3 == nWordCount) {
            cmdStartTrade(psTrimmed, pstConfig);
        } else if (2 == nWordCount) {
            printMessage("Missing arguments, can't start a trade. Please review the syntax.\n");
        } else {
            printMessage("Unknown command\n");
        }
        free(psCopy);
        return 0;
    }

    if (0 == compareIgnoreCase(sWord1, "ENVOY") && 0 == compareIgnoreCase(sWord2, "STATUS")) {
        if (2 == nWordCount) {
            printMessage("Command OK\n");
        } else {
            printMessage("Unknown command\n");
        }
        free(psCopy);
        return 0;
    }

    printMessage("Unknown command\n");
    free(psCopy);
    return -1;
}

static void cmdListRealms(MaesterConfig *pstConfig) {
    int i = 0;
    for (i = 0; i < pstConfig->nNumRoutes; i++) {
        if (0 != compareIgnoreCase(pstConfig->aRoutes[i].sRealmName, "DEFAULT")) {
            printMessage("- ");
            printMessage(pstConfig->aRoutes[i].sRealmName);
            printMessage("\n");
        }
    }
}

static void cmdListProducts(Inventory *pstInventory) {
    displayInventory(pstInventory);
}

static void cmdStartTrade(const char *psInput, MaesterConfig *pstConfig) {
    char sRealm[MAX_REALM_NAME];
    memset(sRealm, 0, sizeof(sRealm));
    getWord(psInput, 2, sRealm, sizeof(sRealm));
    runTradeMenu(sRealm, pstConfig);
}

static void runTradeMenu(const char *psTargetRealm, MaesterConfig *pstConfig) {
    TradeList stTradeList;
    char *psLine = NULL;
    char *psTrimmed = NULL;
    char sWord1[MAX_BUFFER];
    char sProductName[MAX_PRODUCT_NAME];
    char sAmountStr[32];
    char sTempWord[MAX_BUFFER];
    int nWordCount = 0;
    int nAmount = 0;
    int nTradeRunning = 1;
    int nFound = 0;
    int i = 0;
    int j = 0;

    memset(&stTradeList, 0, sizeof(TradeList));
    strncpy(stTradeList.sTargetRealm, psTargetRealm, MAX_REALM_NAME - 1);

    while (nTradeRunning) {
        printMessage(TRADE_PROMPT);
        psLine = readLine(STDIN_FILENO);

        if (NULL == psLine) {
            nTradeRunning = 0;
            break;
        }

        psTrimmed = trimWhitespace(psLine);

        if ('\0' == *psTrimmed) {
            free(psLine);
            continue;
        }

        nWordCount = countWords(psTrimmed);
        memset(sWord1, 0, sizeof(sWord1));
        getWord(psTrimmed, 0, sWord1, sizeof(sWord1));

        if (0 == compareIgnoreCase(sWord1, "send") && 1 == nWordCount) {
            if (stTradeList.nNumItems > 0) {
                writeTradeFile(&stTradeList, pstConfig->sFolderPath);
                printMessage("Trade list sent to ");
                printMessage(psTargetRealm);
                printMessage(".\n");
            } else {
                printMessage("No items in trade list. Nothing to send.\n");
            }
            nTradeRunning = 0;
            free(psLine);
            break;
        }

        if (0 == compareIgnoreCase(sWord1, "cancel") && 1 == nWordCount) {
            printMessage("Trade cancelled.\n");
            nTradeRunning = 0;
            free(psLine);
            break;
        }

        if (0 == compareIgnoreCase(sWord1, "exit") && 1 == nWordCount) {
            printMessage("Trade cancelled.\n");
            nTradeRunning = 0;
            free(psLine);
            break;
        }

        if (0 == compareIgnoreCase(sWord1, "add") && nWordCount >= 3) {
            memset(sAmountStr, 0, sizeof(sAmountStr));
            getWord(psTrimmed, nWordCount - 1, sAmountStr, sizeof(sAmountStr));
            nAmount = stringToInt(sAmountStr);

            memset(sProductName, 0, sizeof(sProductName));
            for (i = 1; i < nWordCount - 1; i++) {
                memset(sTempWord, 0, sizeof(sTempWord));
                getWord(psTrimmed, i, sTempWord, sizeof(sTempWord));
                if (i > 1) {
                    strncat(sProductName, " ", MAX_PRODUCT_NAME - strlen(sProductName) - 1);
                }
                strncat(sProductName, sTempWord, MAX_PRODUCT_NAME - strlen(sProductName) - 1);
            }

            if (nAmount <= 0) {
                printMessage("Invalid amount.\n");
                free(psLine);
                continue;
            }

            nFound = 0;
            for (i = 0; i < stTradeList.nNumItems; i++) {
                if (0 == compareIgnoreCase(stTradeList.aItems[i].sProductName, sProductName)) {
                    stTradeList.aItems[i].nAmount += nAmount;
                    nFound = 1;
                    break;
                }
            }

            if (0 == nFound && stTradeList.nNumItems < MAX_TRADE_ITEMS) {
                strncpy(stTradeList.aItems[stTradeList.nNumItems].sProductName,
                        sProductName, MAX_PRODUCT_NAME - 1);
                stTradeList.aItems[stTradeList.nNumItems].nAmount = nAmount;
                stTradeList.nNumItems++;
            }

            free(psLine);
            continue;
        }

        if (0 == compareIgnoreCase(sWord1, "remove") && nWordCount >= 3) {
            memset(sAmountStr, 0, sizeof(sAmountStr));
            getWord(psTrimmed, nWordCount - 1, sAmountStr, sizeof(sAmountStr));
            nAmount = stringToInt(sAmountStr);

            memset(sProductName, 0, sizeof(sProductName));
            for (i = 1; i < nWordCount - 1; i++) {
                memset(sTempWord, 0, sizeof(sTempWord));
                getWord(psTrimmed, i, sTempWord, sizeof(sTempWord));
                if (i > 1) {
                    strncat(sProductName, " ", MAX_PRODUCT_NAME - strlen(sProductName) - 1);
                }
                strncat(sProductName, sTempWord, MAX_PRODUCT_NAME - strlen(sProductName) - 1);
            }

            for (i = 0; i < stTradeList.nNumItems; i++) {
                if (0 == compareIgnoreCase(stTradeList.aItems[i].sProductName, sProductName)) {
                    stTradeList.aItems[i].nAmount -= nAmount;
                    if (stTradeList.aItems[i].nAmount <= 0) {
                        for (j = i; j < stTradeList.nNumItems - 1; j++) {
                            memcpy(&stTradeList.aItems[j], &stTradeList.aItems[j + 1],
                                   sizeof(TradeItem));
                        }
                        stTradeList.nNumItems--;
                    }
                    break;
                }
            }

            free(psLine);
            continue;
        }

        printMessage("Unknown trade command\n");
        free(psLine);
    }
}

static int writeTradeFile(const TradeList *pstTradeList, const char *psFolderPath) {
    char sFilePath[MAX_PATH];
    char sReverse[32];
    char sAmountBuf[32];
    int nFd = 0;
    int i = 0;
    int nLen = 0;
    int nVal = 0;
    int nIdx = 0;
    int nRevIdx = 0;
    int k = 0;

    if (NULL == pstTradeList || NULL == psFolderPath) {
        return -1;
    }

    memset(sFilePath, 0, sizeof(sFilePath));
    strncpy(sFilePath, psFolderPath, MAX_PATH - 50);
    strncat(sFilePath, "/trade_", MAX_PATH - strlen(sFilePath) - 1);
    strncat(sFilePath, pstTradeList->sTargetRealm, MAX_PATH - strlen(sFilePath) - 1);
    strncat(sFilePath, ".txt", MAX_PATH - strlen(sFilePath) - 1);

    nFd = open(sFilePath, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (nFd < 0) {
        printMessage("ERROR: Could not create trade file.\n");
        return -1;
    }

    for (i = 0; i < pstTradeList->nNumItems; i++) {
        nLen = strlen(pstTradeList->aItems[i].sProductName);
        write(nFd, pstTradeList->aItems[i].sProductName, nLen);
        write(nFd, " ", 1);

        memset(sAmountBuf, 0, sizeof(sAmountBuf));
        memset(sReverse, 0, sizeof(sReverse));
        nVal = pstTradeList->aItems[i].nAmount;
        nIdx = 0;
        nRevIdx = 0;

        if (0 == nVal) {
            sAmountBuf[0] = '0';
            nIdx = 1;
        } else {
            while (nVal > 0) {
                sReverse[nRevIdx] = '0' + (nVal % 10);
                nRevIdx++;
                nVal = nVal / 10;
            }
            for (k = nRevIdx - 1; k >= 0; k--) {
                sAmountBuf[nIdx] = sReverse[k];
                nIdx++;
            }
        }

        write(nFd, sAmountBuf, nIdx);
        write(nFd, "\n", 1);
    }

    close(nFd);
    return 0;
}

static void cmdExit(MaesterConfig *pstConfig, int *pnRunning) {
    printMessage("The Maester of ");
    printMessage(pstConfig->sRealmName);
    printMessage(" signs off. The ravens rest.\n");
    *pnRunning = 0;
}
